// background.js — MV3 service worker. Runs as ES module (see manifest).
//
// Responsibilities:
//   A) HUMANIZE message: quota → tone-guard classify → Sonnet rewrite →
//      imperfections → ceo lowercase safety net → counter increment.
//   B) DEV_MODE direct API key (TEMP — replace with backend proxy).
//   C) Right-click context menu humanizer.
//
// Privacy: never store or log email text. Only counters + flags.

import { buildSystemPrompt } from './prompts.js';
import applyRandomImperfection from './imperfections.js';

// --- DEV_MODE ---------------------------------------------------------------
// TODO: replace with backend proxy before production.
const DEV_MODE = true;
const DEV_API_KEY = DEV_MODE ? 'YOUR_DEV_KEY_HERE' : null;

const ANTHROPIC_URL = 'https://api.anthropic.com/v1/messages';
const ANTHROPIC_VERSION = '2023-06-01';
const HAIKU_MODEL  = 'claude-haiku-4-5';
const SONNET_MODEL = 'claude-sonnet-4-20250514';

const SENSITIVE_TYPES = new Set(['APOLOGY', 'LEGAL', 'HR', 'MEDICAL']);
const ALLOWED_TYPES = [
  'COLD_OUTREACH', 'FOLLOW_UP', 'RESPONSE', 'APOLOGY',
  'LEGAL', 'HR', 'MEDICAL', 'NEGOTIATION', 'PERSONAL', 'OTHER',
];

const CLASSIFIER_PROMPT =
  'Classify this email. Respond with ONLY one of these exact words, nothing else: ' +
  'COLD_OUTREACH, FOLLOW_UP, RESPONSE, APOLOGY, LEGAL, HR, MEDICAL, NEGOTIATION, PERSONAL, OTHER';

// --- Helpers ----------------------------------------------------------------

function todayISO() {
  return new Date().toISOString().slice(0, 10); // YYYY-MM-DD, UTC
}

async function getQuotaState() {
  const keys = ['dailyCount', 'lastResetDate', 'isPro', 'apiKey'];
  const s = await chrome.storage.local.get(keys);
  return {
    dailyCount: s.dailyCount ?? 0,
    lastResetDate: s.lastResetDate ?? null,
    isPro: s.isPro === true,
    apiKey: s.apiKey || null,
  };
}

async function rolloverIfNewDay(state) {
  const today = todayISO();
  if (state.lastResetDate !== today) {
    state.dailyCount = 0;
    state.lastResetDate = today;
    await chrome.storage.local.set({ dailyCount: 0, lastResetDate: today });
  }
  return state;
}

function pickApiKey(userKey) {
  // BYOK takes priority. Falls back to DEV key while DEV_MODE is on.
  if (userKey) return userKey;
  if (DEV_API_KEY) return DEV_API_KEY;
  return null;
}

async function callAnthropic({ apiKey, model, system, userText, maxTokens }) {
  const res = await fetch(ANTHROPIC_URL, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': ANTHROPIC_VERSION,
      // MV3 service worker is treated as a browser context by the API.
      'anthropic-dangerous-direct-browser-access': 'true',
    },
    body: JSON.stringify({
      model,
      max_tokens: maxTokens,
      system,
      messages: [{ role: 'user', content: userText }],
    }),
  });
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw new Error(`Anthropic ${res.status}: ${body.slice(0, 300)}`);
  }
  const data = await res.json();
  const block = data?.content?.find(c => c.type === 'text');
  return block?.text ?? '';
}

async function classifyEmail(apiKey, text) {
  try {
    const out = await callAnthropic({
      apiKey,
      model: HAIKU_MODEL,
      system: CLASSIFIER_PROMPT,
      userText: text,
      maxTokens: 16,
    });
    const tag = out.trim().toUpperCase().replace(/[^A-Z_]/g, '');
    return ALLOWED_TYPES.includes(tag) ? tag : 'OTHER';
  } catch {
    // If the classifier fails we let the rewrite continue — the worst case
    // is missing a sensitive-email warning, not a correctness bug.
    return 'OTHER';
  }
}

// --- HUMANIZE handler -------------------------------------------------------

async function handleHumanize({ text, mode, voiceProfile, force }) {
  if (!text || !mode) return { error: 'BAD_REQUEST' };

  let state = await getQuotaState();
  state = await rolloverIfNewDay(state);

  const isFree = !state.isPro && !state.apiKey;
  if (isFree && state.dailyCount >= 2) {
    return { error: 'LIMIT_REACHED' };
  }

  const apiKey = pickApiKey(state.apiKey);
  if (!apiKey) return { error: 'NO_API_KEY' };

  // 2) Tone guard.
  if (!force && mode !== 'subtle') {
    const emailType = await classifyEmail(apiKey, text);
    if (SENSITIVE_TYPES.has(emailType)) {
      return { warning: 'SENSITIVE_EMAIL', emailType };
    }
  }

  // 3 + 4) Build prompt + main rewrite.
  const system = buildSystemPrompt(mode, voiceProfile);
  let result;
  try {
    result = await callAnthropic({
      apiKey,
      model: SONNET_MODEL,
      system,
      userText: `Rewrite this email:\n\n${text}`,
      maxTokens: 1024,
    });
  } catch (e) {
    return { error: 'API_ERROR', message: e.message };
  }

  // 5) Post-processing imperfections.
  result = applyRandomImperfection(result, mode);

  // 6) CEO lowercase safety net.
  if (mode === 'ceo') result = result.toLowerCase();

  // 7) Increment quota for free tier only.
  if (isFree) {
    await chrome.storage.local.set({ dailyCount: state.dailyCount + 1 });
  }

  return { result };
}

// --- Message bus ------------------------------------------------------------

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === 'HUMANIZE') {
    handleHumanize(msg).then(sendResponse).catch(e => sendResponse({ error: 'FATAL', message: String(e) }));
    return true; // async response
  }
  return false;
});

// --- C) Context menu --------------------------------------------------------

const MENU_ID = 'fumbl-humanize-selection';

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: MENU_ID,
    title: 'Fumbl — Humanize selection',
    contexts: ['selection'],
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== MENU_ID || !tab?.id) return;
  chrome.tabs.sendMessage(tab.id, {
    type: 'CONTEXT_HUMANIZE',
    text: info.selectionText ?? '',
  });
});
