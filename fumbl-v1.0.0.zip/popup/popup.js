// popup.js — extension popup logic. Reads/writes chrome.storage.local,
// keeps the UI in sync, and handles the dev stub for Stripe checkout.

const DEFAULT_MODE = 'subtle';
const FREE_DAILY_LIMIT = 2;

// TODO: replace with real Stripe checkout URL once backend is live.
const CHECKOUT_URL = 'https://fumbl.com/checkout';

const $ = (sel) => document.querySelector(sel);

function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

async function getState() {
  const s = await chrome.storage.local.get([
    'preferredMode', 'dailyCount', 'lastResetDate', 'isPro', 'apiKey', 'history',
  ]);
  // If a new day, treat the count as 0 for display purposes — the source of
  // truth still lives in background.js and resets on next call.
  const dailyCount = s.lastResetDate === todayISO() ? (s.dailyCount ?? 0) : 0;
  return {
    preferredMode: s.preferredMode || DEFAULT_MODE,
    dailyCount,
    isPro: s.isPro === true,
    apiKey: s.apiKey || '',
    historyLen: Array.isArray(s.history) ? s.history.length : 0,
  };
}

function setActiveMode(mode) {
  document.querySelectorAll('.mode-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.mode === mode);
  });
}

function renderUsage(state) {
  const line = $('#usage-line');
  const upgrade = $('#upgrade-btn');
  if (state.isPro) {
    line.textContent = 'Pro — unlimited';
    line.removeAttribute('data-zero');
    upgrade.hidden = true;
    return;
  }
  if (state.apiKey) {
    line.textContent = 'BYOK active — unlimited';
    line.removeAttribute('data-zero');
    upgrade.hidden = true;
    return;
  }
  const left = Math.max(0, FREE_DAILY_LIMIT - state.dailyCount);
  line.textContent = `${left} free rewrite${left === 1 ? '' : 's'} today`;
  line.toggleAttribute('data-zero', left === 0);
  upgrade.hidden = false;
}

function renderHistory(state) {
  $('#history-count').textContent = `History: ${state.historyLen}`;
}

function renderApiKey(state) {
  $('#api-key').value = state.apiKey || '';
}

async function refresh() {
  const state = await getState();
  setActiveMode(state.preferredMode);
  renderUsage(state);
  renderHistory(state);
  renderApiKey(state);
}

// --- Wire up ---------------------------------------------------------------

document.addEventListener('DOMContentLoaded', async () => {
  // Version
  const v = chrome.runtime.getManifest().version;
  $('#version').textContent = `v${v}`;

  await refresh();

  // Mode buttons
  document.querySelectorAll('.mode-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const mode = btn.dataset.mode;
      setActiveMode(mode);
      await chrome.storage.local.set({ preferredMode: mode });
    });
  });

  // API key save
  $('#api-save').addEventListener('click', async () => {
    const val = $('#api-key').value.trim();
    const status = $('#api-status');
    await chrome.storage.local.set({ apiKey: val || null });
    status.textContent = val ? 'Saved.' : 'Cleared.';
    status.removeAttribute('data-error');
    await refresh();
    setTimeout(() => { status.textContent = ''; }, 2000);
  });

  // Upgrade
  $('#upgrade-btn').addEventListener('click', () => {
    // Dev stub: surface intent without opening a real Stripe page yet.
    console.log('would open Stripe checkout:', CHECKOUT_URL);
    chrome.tabs.create({ url: CHECKOUT_URL });
  });

  // Clear history
  $('#clear-history').addEventListener('click', async () => {
    // Drop history list + every undo_* snapshot. Email text never leaves the
    // device, but clearing it on user request is the right default.
    const all = await chrome.storage.local.get(null);
    const undoKeys = Object.keys(all).filter(k => k.startsWith('undo_'));
    await chrome.storage.local.remove([...undoKeys, 'history', 'last_original']);
    await refresh();
  });

  // Live-update if storage changes elsewhere (background increment, etc.)
  chrome.storage.onChanged.addListener((_changes, area) => {
    if (area === 'local') refresh();
  });
});
